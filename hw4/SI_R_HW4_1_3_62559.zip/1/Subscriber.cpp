#include "Subscriber.hpp"

Subscriber::Subscriber(const std::string& id) : id(id)
{
}
