#include "Message.hpp"

Message::Message(int data) : data(data)
{
}
