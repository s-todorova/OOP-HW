#pragma once

class Message {
public:
	Message(int data);

	const int data;
};